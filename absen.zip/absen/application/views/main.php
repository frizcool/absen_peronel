<form action="proses" method="post">

          <table class="table table-striped table-hover table-dark">
              <thead style="font-size:12px;">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Pkt</th>
                  <th scope="col">S'tus</th>
                  <th scope="col">Ket</th>
                  <th scope="col"><a href="<?= base_url("ui/tambah"); ?>"><i class="fas fa-plus-circle text-primary"></i></a></th>
                </tr>
              </thead>
              <tbody style="font-size:12px;">
                <?php $no=0; foreach ($tabel as $key): $no++; ?>
                  <tr id="warna<?= $key->id; ?>" <?php if($key->status=="H"){ echo "class='table-success text-body'"; }?>>
                    <th scope="row"><?= $no; ?></th>
                    <td><?= $key->nama;  ?></td>
                    <td><?= $key->pangkat;  ?></td>
                    <td><input type="checkbox" name="status[]" <?php if($key->status=="H"){ echo "checked"; }?> value="<?= $key->id; ?>" id="myCheck<?= $key->id; ?>"  onclick="myFunction()"></td>
                    <td>
                      <form class="" action="proses" method="post">

                        <span id="text<?= $key->id; ?>">TK</span>
                        <input type="hidden" name="kunci" value="<?= $key->id; ?>"/>
                        <select  name="pilihan" onchange="this.form.submit();" id="select<?= $key->id; ?>">
                          <option value=""></option>
                          <option value="DD" <?php if($key->status=="DD"){ echo "selected"; }?>>DD</option>
                          <option value="DL"  <?php if($key->status=="DL"){ echo "selected"; }?>>DL</option>
                          <option value="DIK" <?php if($key->status=="DIK"){ echo "selected"; }?>>DIK</option>
                          <option value="SKT" <?php if($key->status=="SKT"){ echo "selected"; }?>>SKT</option>
                          <option value="TAR" <?php if($key->status=="TAR"){ echo "selected"; }?>>TAR</option>
                          <option value="DK" <?php if($key->status=="DK"){ echo "selected"; }?>>DK</option>
                          <option value="IZ" <?php if($key->status=="IZ"){ echo "selected"; }?>>IZ</option>
                        </select>
                      </td>
                      </form>
                      <td>
                        <a href="<?= base_url("ui/edit?id=").$key->id; ?>"><span class="fas fa-edit text-success"></span></a>
                        &nbsp;&nbsp;
                        <a href="<?= base_url("ui/del_proses?id=").$key->id; ?>" onclick="return confirm('Yakin akan dihapus?');"><span class="fas fa-trash text-danger"></span></a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <script>
            function myFunction() {
            <?php foreach ($tabel as $key):?>
              var element<?= $key->id; ?> = document.getElementById("warna<?= $key->id; ?>");
              var checkBox<?= $key->id; ?> = document.getElementById("myCheck<?= $key->id; ?>");
              var text<?= $key->id; ?> = document.getElementById("text<?= $key->id; ?>");
              if (checkBox<?= $key->id; ?>.checked == true){
                text<?= $key->id; ?>.innerHTML = "H";
                element<?= $key->id; ?>.classList.add("table-success");
                element<?= $key->id;?>.classList.add("text-body");
                document.getElementById("select<?= $key->id; ?>").disabled=true;
              } else {
                 text<?= $key->id;?>.innerHTML = "TK";
                 document.getElementById("select<?= $key->id; ?>").disabled=false;
                 element<?= $key->id; ?>.classList.remove("table-success");
                 element<?= $key->id; ?>.classList.remove("text-body");
              }
              <?php endforeach; ?>
            }
            </script>

<button type="submit" name="simpan" value="tambah" class="btn btn-primary">Proses</button>
</form>
<a href="reset" onclick="return confirm('Yakin Akan di Reset');">
  <button type="button" class="btn btn-danger">Reset</button>
</a>
