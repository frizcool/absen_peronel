<form action="add_proses" method="post">
    <div class="form-group">
      <label for="exampleInputEmail1">Nama</label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Personel" name="nama">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Pangkat</label>
      <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Pangkat" name="pangkat">
    </div>
    <button type="submit" name="simpan" value="tambah" class="btn btn-primary">Submit</button>

    <a href="main">
      <button type="button" class="btn btn-dark">Kembali</button>
    </a>
</form>
