<table>
  <tr>
    <td><strong>JUMLAH</strong></td>
    <td><strong>:</strong></td>
    <td><strong> <?= $jumlah->jml;  ?></strong></td>
  </tr>
  <tr>
    <td><strong>KURANG</strong></td>
    <td><strong>:</strong></td>
    <td><strong> <?= $kurang->jml;  ?></strong></td>
  </tr>
  <tr>
    <td><strong>HADIR</strong></td>
    <td><strong>:</strong></td>
    <td><strong><?php $tot=$jumlah->jml-$kurang->jml; echo $tot; ?></strong></td>
  </tr>
  <tr>
    <td colspan="3"> <hr class="text-secondary"> </td>
  </tr>
  <?php foreach ($keterangan as $key): ?>
    <tr>
      <td><?php if($key->status==''){ echo "TK";}else{ echo $key->status;}  ?></td>
      <td>:</td>
      <td><?= $key->jml;  ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<a href="main">
  <button type="button" class="btn btn-dark">Kembali</button>
</a>
