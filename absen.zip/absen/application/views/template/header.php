<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title><?= $judul;  ?></title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url("assets/css/style4.css"); ?>">

    <!-- Font Awesome JS -->
    <script defer src="<?php echo base_url("assets/fontawesome/js/solid.js"); ?>" ></script>
    <script defer src="<?php echo base_url("assets/fontawesome/js/fontawesome.js"); ?>"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/dataTables/datatables.min.css"); ?>"/>

</head>

<body class="bg-secondary text-white">

    <div class="wrapper">
        <!-- Sidebar  -->
        <!-- <nav id="sidebar" class="bg-dark text-white">
            <div class="sidebar-header">
                <h3 align="center">ABSEN PERSONEL</h3>
                <strong>PK</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-home"></i>
                        Home
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#">Home 1</a>
                        </li>
                        <li>
                            <a href="#">Home 2</a>
                        </li>
                        <li>
                            <a href="#">Home 3</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?= base_url("ui/daftar_keluarga"); ?>">
                        <i class="fas fa-users"></i>
                        Daftar Keluarga
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Untility
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="<?= base_url("ui/provinsi");  ?>">Provinsi</a>
                        </li>
                        <li>
                            <a href="<?= base_url("ui/kabupaten");  ?>">Kabupaten/Kota</a>
                        </li>
                        <li>
                            <a href="<?= base_url("ui/kecamatan");  ?>">Kecamatan</a>
                        </li>
                        <li>
                            <a href="<?= base_url("ui/kelurahan");  ?>">Desa/Kelurahan</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-image"></i>
                        Portfolio
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-question"></i>
                        FAQ
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-paper-plane"></i>
                        Contact
                    </a>
                </li>
            </ul>

        </nav> -->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                <div class="container-fluid">

                    <!-- <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-align-justify"></i>
                    </button> -->
                    <!-- <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button> -->
                    <h4><?= strtoupper($judul); ?></h4>
                    <!-- <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="<?php echo base_url("ui/logout"); ?>" >Logout</a>
                            </li>
                        </ul>
                    </div> -->
                </div>
            </nav>
