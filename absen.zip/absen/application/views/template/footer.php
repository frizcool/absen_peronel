</div>
</div>
<!-- Footer -->
<footer class="page-footer font-small" style="background: #262a2d !important;">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href="https://friztech.my.id" target="_blank"><i style="color:yellow;"> Friztech</i></a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="<?php echo base_url("assets/js/jquery-3.3.1.slim.min.js"); ?>" ></script>
<!-- Popper.JS -->
<script src="<?php echo base_url("assets/js/popper.min.js"); ?>" ></script>
<!-- Bootstrap JS -->
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>" ></script>
<!-- Datatables -->
<script type="text/javascript" src="<?php echo base_url("assets/dataTables/datatables.min.js"); ?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>

<script type="text/javascript">
$(document).ready(function() {
$('#example').DataTable();
} );
</script>
</body>

</html>
