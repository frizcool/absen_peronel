<form action="edit_proses" method="post">
    <div class="form-group">
      <label for="exampleInputEmail1">Nama</label>
      <input type="text" value="<?= $table->nama;  ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Personel" name="nama">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Pangkat</label>
      <input type="text" class="form-control" value="<?= $table->pangkat;  ?>" id="exampleInputPassword1" placeholder="Pangkat" name="pangkat">
    </div>
    <input type="hidden" name="kunci" value="<?= $table->id;  ?>">
    <button type="submit" class="btn btn-warning">Edit</button>

    <a href="main">
      <button type="button" class="btn btn-dark">Kembali</button>
    </a>
</form>
