<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ui extends CI_Controller {

   public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->helper('file');
		$this->load->helper('form');
		$this->load->model('mfriz');
	}
	public function index()
	{
		redirect("ui/main");
	}
  public function verification(){
      redirect("ui/main");
  }
  public function main(){
    $data["judul"]="ABSEN PERSONEL";
    // $data["table"]=$this->mfriz->get_list();
    $data["halaman"]="main";
    $data["tabel"]=$this->mfriz->get_list("tb_personel");
		$this->load->view('home',$data);
  }
  public function reset(){
    $obj["status"]='';
    $this->mfriz->update("tb_personel",$obj,"id!=''");  redirect("ui/main");
  }

  public function proses(){
    $status=$this->input->post("status");
    $pilihan=$this->input->post("pilihan");
    $kunci=$this->input->post("kunci");
    $objx["status"]="H";
    if (!empty($status)) {
      foreach ($status as $key ) {
          $this->mfriz->update("tb_personel",$objx,"id='$key'");
      }
      redirect("ui/tampil");
    }
    else if (!empty($kunci)) {
      $obj["status"]=$pilihan;
      $this->mfriz->update("tb_personel",$obj,"id='$kunci'");

      $aksi=$this->input->post("simpan");
      if(!empty($aksi)){

        redirect("ui/tampil");
      }else{
      redirect("ui/main");
      }
    }else{
      redirect("ui/main");
    }


  }

    public function add_proses(){
      $obj['nama']=$this->input->post("nama");
      $obj['pangkat']=$this->input->post("pangkat");
      $this->mfriz->insert("tb_personel",$obj);
      redirect("ui/main");
    }

    public function edit_proses(){
      $obj['nama']=$this->input->post("nama");
        $x['id']=$this->input->post("kunci");
      $obj['pangkat']=$this->input->post("pangkat");
      $this->mfriz->update("tb_personel",$obj,$x);
      redirect("ui/main");
    }
    public function del_proses(){
      $id['id']=$this->input->get("id");
      $this->mfriz->delete("tb_personel",$id);
      redirect("ui/main");
    }

  public function tampil(){
    $data["judul"]="REKAPITULASI ABSEN PERSONEL";
    // $data["table"]=$this->mfriz->get_list();
    $data["halaman"]="rekap";
    $data["jumlah"]=$this->mfriz->select("count(status) as jml FROM tb_personel");
    $data["kurang"]=$this->mfriz->select("count(status) as jml FROM tb_personel where status!='H' ");
    $data["keterangan"]=$this->mfriz->select2("count(status) as jml, status FROM tb_personel where status!='H' group by status ");
		$this->load->view('home',$data);
  }
  public function tambah(){
    $data["judul"]="TAMBAH PERSONEL";
    // $data["table"]=$this->mfriz->get_list();
    $data["halaman"]="tambah";
		$this->load->view('home',$data);
  }
  public function edit(){
    $id['id']=$this->input->get("id");
    $data["judul"]="EDIT PERSONEL";
    $data["table"]=$this->mfriz->tampil_record("tb_personel",$id);
    $data["halaman"]="edit";
		$this->load->view('home',$data);
  }

}
