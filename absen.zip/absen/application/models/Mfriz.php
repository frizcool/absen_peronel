<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Mfriz extends CI_Model
{
	public function size($size)
	{
	    if ($size < 1024) {
	        return "{$size} bytes";
	    } elseif ($size < 1048576) {
	        $size_kb = round($size/1024);
	        return "{$size_kb} KB";
	    } else {
	        $size_mb = round($size/1048576, 1);
	        return "{$size_mb} MB";
	    }
		}
	public function file_extension($path)
	{
		$ext='';
		$extension = substr(strrchr($path, '.'), 1);
		switch($extension) {
			case 'pdf':$ext='fa fa-file-pdf-o';		break;
			case 'doc':$ext='fa fa-file-word-o';		break;
			case 'docx':$ext='fa fa-file-word-o';		break;
			case 'xlsx':$ext='fa fa-file-excel-o';		break;
			case 'xlsx':$ext='fa fa-file-word-o';		break;
			case 'txt':$ext='fa fa-file-o';		break;
			case 'ppt':$ext='fa file-powerpoint-o';		break;
			case 'pptx':$ext='fa file-powerpoint-o';		break;
			case 'jpg':$ext='image';		break;
			case 'png':$ext='image';		break;
			case 'gif':$ext='image';		break;

			default:
			$ext='fa fa-file-o';		break;

				break;
		}
		return $ext;
	}
	public function select($string)
	{
			$this->db->select($string);
			$query = $this->db->get();
			if ($query->num_rows() > 0) {
					return $query->row();
			}

	}

	public function select2($string)
	{
			$this->db->select($string);
			$query = $this->db->get()->result();

					return $query;

	}
	 public function tampil_record($tabel,$key=null) {
		    $this->db->from($tabel);

			    if ($key!=null) {
			       $this->db->where($key);
			    }
			    $query = $this->db->get();
			    if ($query->num_rows() > 0) {
			        return $query->row();
			    }
		}
public function get_list($table, $where = FALSE, $order=FALSE, $join=FALSE, $kd_join=FALSE,$group=FALSE)
	{
		if ($join) {
			$this->db->join($join, $kd_join, 'left');
		}
		if ($where) {
			$this->db->where($where);
		}
		if ($order) {
			$this->db->ORDER_BY($order);
		}
		if ($group) {
		$this->db->group_by($group);
		}

		return $this->db->get($table)->result();
}
public function get_list2($table, $where = FALSE, $order=FALSE, $join=FALSE, $kd_join=FALSE, $join2=FALSE, $kd_join2=FALSE,$group=FALSE)
	{
		if ($join) {
			$this->db->join($join, $kd_join, 'left');
		}
		if ($join2) {
			$this->db->join($join2, $kd_join2, 'left');
		}
		if ($where) {
			$this->db->where($where);
		}
		if ($order) {
			$this->db->ORDER_BY($order);
		}
		if ($group) {
		$this->db->group_by($group);
		}

		return $this->db->get($table)->result();
}
public function get_list3($table, $where = FALSE, $order=FALSE, $join=FALSE, $kd_join=FALSE, $join2=FALSE, $kd_join2=FALSE, $join3=FALSE, $kd_join3=FALSE,$group=FALSE)
	{
		if ($join) {
			$this->db->join($join, $kd_join, 'left');
		}
		if ($join2) {
			$this->db->join($join2, $kd_join2, 'left');
		}
		if ($join3) {
			$this->db->join($join3, $kd_join3, 'left');
		}
		if ($where) {
			$this->db->where($where);
		}
		if ($order) {
			$this->db->ORDER_BY($order);
		}
		if ($group) {
		$this->db->group_by($group);
		}

		return $this->db->get($table)->result();
}

function get_export($table){

			 $response = array();

			 // Select record
			 //$this->db->select('username,name,gender,email');
			 $q = $this->db->get($table);
			 $response = $q->result_array();

			 return $response;
	 }

	public function insert($table, $param)
	{
		$this->db->insert($table, $param);
		return $this->db->insert_id();
	}

	public function update($table, $set, $where)
	{
		$this->db->where($where);
		$this->db->update($table, $set);
		return $this->db->affected_rows();
	}

	public function delete($table, $where)
	{
		$this->db->where($where);
		$this->db->delete($table);
		return $this->db->affected_rows();
	}

	function selisih_tanggal($d){
		$date1=date_create(date("Y-m-d"));
		$date2=date_create($d);
		$diff=date_diff($date1,$date2);
		$diff=$diff->format("%a");
		return $diff;
	  }

		  function minggu($date){
		    $tglan=date_parse($date);
		    $tanggalan =  $tglan["day"];
		    $bulanan=$tglan["month"];
		    $tahunan=$tglan["year"];
		    $tanggalAwalBulan = mktime(0, 0, 0, $bulanan, 1, $tahunan);
		    $mingguAwalBulan = (int) date("W", $tanggalAwalBulan);
		    $tanggalYangDicari = mktime(0, 0, 0, $bulanan, $tanggalan, $tahunan);
		    $mingguTanggalYangDicari = (int) date("W", $tanggalYangDicari);
		    $mingguKe=$mingguTanggalYangDicari - $mingguAwalBulan + 1;
		    if($mingguKe<0) { $mingguKe = $mingguTanggalYangDicari; }
		    return $mingguKe;
		  }

	function count_record($tabel,$where=null, $order=FALSE, $join=FALSE, $kd_join=FALSE,$group=FALSE){
			$this->db->from($tabel);
		if ($where != null) {
	       $this->db->where($where);
	    }
				if ($join) {
					$this->db->join($join, $kd_join, 'left');
				}
			if ($order) {
				$this->db->ORDER_BY($order);
			}
			if ($group) {
			$this->db->group_by($group);
			}
    	$query = $this->db->get()->num_rows();
    	 //cek apakah ada barang
		return $query;
	}



}
